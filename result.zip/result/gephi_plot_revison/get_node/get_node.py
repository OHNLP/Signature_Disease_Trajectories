import pandas as pd

cancer_list = ['pancreatic_cancer', 'sarcoma-retroperitoneum', 'sarcoma-trunk_extremities']
file_list = ['from_cancer.csv', 'to_cancer.csv', 'other.csv']

for cancer in cancer_list:
    for file in file_list:
        cur_file = '../'+cancer+'/'+file
        node_file = '../'+cancer+'/nodes.csv'
        df_edge = pd.read_csv(cur_file)
        df_node = pd.read_csv(node_file)

        connected_ids = set(df_edge['Source']).union(set(df_edge['Target']))
        filtered_df = df_node[df_node['Id'].isin(connected_ids)]

        # 保存结果
        filtered_df.to_csv('../'+cancer+'/node_'+file, index=False)
